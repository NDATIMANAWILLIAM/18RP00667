public class question_fludice{
	String color;
	public question_fludice(String color)
	{
		this.color=color;
	}

	void display()
	{
		System.out.println(color);
	}
public static void main(String[] args) {
	question_fludice b=new question_fludice("blue");
	b.display();
}

}