public class question_wheel{
	int count;
	int position=1;
	public question_wheel(int count)
	{
	this.count=count;	
	}
	void display()
	{
		System.out.println(count);
	}
public static void main(String[] args) {
	question_wheel b=new question_wheel(1);
	b.display();
}

}
