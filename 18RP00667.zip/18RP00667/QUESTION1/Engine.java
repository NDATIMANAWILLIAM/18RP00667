public class engine{

	String eng="BMW";

	void display()
	{
		System.out.println("engine is: "+ eng);
	}

	public static void main(String[] args) {
	engine n=new engine();
	n.display();
}
}