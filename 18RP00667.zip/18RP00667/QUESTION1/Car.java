import java.util.*;
public class car{
question_wheel;
String name;
engine eng;
car(String name,question_wheel,engine eng)
{
	
}
void display(){
System.out.println("my name is :"+name);
System.out.println("count is :"+count.question_wheel);
System.out.println("engine is :"+eng.engine);

ArrayList c=new ArrayList();
c.add("1");
c.add("2");
c.add("3");
for(int a=0;a<c.size();a++)
{
	System.out.println("wheel are:"+ c.get[a]);
}

ArrayList cl=new ArrayList();
cl.add("yellow");
cl.add("red");
cl.add("blue");
for(int b=0;b<cl.size();b++)
{
	System.out.println("fludices are:"+ cl.get[b]);
}


}



	public static void main(String[] args) {

		question_wheel w=new question_wheel(1);
		engine e=new engine("BMW");
		car cont=new car("CRUS",e,w);
		cont.name="TOKIYO";
		cont.display();

	}
} 