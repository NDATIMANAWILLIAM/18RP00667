public class controller
{
public static void main(String[] args) {
	
	System.out.println("I am Server");

	System.out.println("I am  Client");

	System.out.println("I am  Utility");

}
}