public class item
{
String name,category;
Double price;
item(String name,String category,Double price)
{
	this.name=name;
	this.category=category;
	this.price=price;
}
void display()
{
	System.out.println("name is:"+name+"category is:"+category+"price is:"+price);
}
public static void main(String[] args) {
	item it=new item("school","ab",100.100);
	it.display();
}
}