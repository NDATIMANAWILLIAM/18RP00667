public class controller{

	car c;
	household house;
	item it;
	property p;
	controller(car c,household house,item it,property p)
	{
this.c=c;
this.house=house;
this.it=it;
this.p=p;
	}
	void display()
	{
		System.out.println("platenumber is:"+c.platenumber+"manufactured date is:"+c.manufactured);
		System.out.println("condition is:"+house.condition+"picture is:"+house.picture);
		System.out.println("name is:"+it.name+"category is:"+it.category+"price is:"+it.price);
			System.out.println("bedroom is:"+p.bedroom+"area is:"+p.area+"age is:"+p.age);
	}
	public static void main(String[] args) {
		
		car ca=new car("bb123","2/1/2010");
		household h=new household("good","long");
		item i=new item("school","ab",200.1);

		property p1=new property(2,40,8);

		controller c1=new controller(ca,h,i,p1);
		c1.display();

	}
}