public class household
{
String condition,picture;

household(String condition,String picture)
{
	this.condition=condition;
	this.picture=picture;
}
void display()
{
	System.out.println("condition is:"+condition+"picture is:"+picture);
}
public static void main(String[] args) {
	household h=new household("bad","short");
	h.display();
}
}