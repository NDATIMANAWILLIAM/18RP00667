public class property
{
int bedroom,area,age;
property(int bedroom,int area,int age)
{
	this.bedroom=bedroom;
	this.area=area;
	this.age=age;
}
void display()
{
	System.out.println("bedroom is:"+bedroom+"area is:"+area+"age is:"+age);
}
public static void main(String[] args) {
	property p=new property(1,30,5);
	p.display();
}
}