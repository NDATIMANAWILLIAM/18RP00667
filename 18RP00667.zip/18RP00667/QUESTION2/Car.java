public class car
{
String platenumber;
String manufactured;

car(String platenumber,String manufactured)
{
	this.platenumber=platenumber;
	this.manufactured=manufactured;
}
void display()
{
	System.out.println("platenumber is:"+platenumber+"manufactured date is:"+manufactured);
}
public static void main(String[] args) {
	car c=new car("aa234","2/2/2000");
	c.display();
}
}